export const PORT=5555;
export const mongoDBURL = 'mongodb+srv://akash:Biyyam%402004@bookstoremern.raw0yau.mongodb.net/Books-collection?retryWrites=true&w=majority&appName=bookstoremern';
